const carro = {
    marca: "Toyta",
    modelo: "camionete",
    ano: "2000"
}
console.log(carro)