const carro = {
    marca: "Toyta",
    modelo: "camionete",
    ano: "2000"
}
carro.ano = "2021"
const { marca, ano } = carro;
console.log(marca)
console.log(ano)