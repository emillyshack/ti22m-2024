const carro = {
    marca: "Toyta",
    modelo: "camionete",
    ano: "2000"
}
carro.cor = "preto"
delete carro.modelo;
console.log(carro)
