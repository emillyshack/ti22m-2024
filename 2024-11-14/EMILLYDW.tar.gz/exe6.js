const biblioteca = [ 
    {titulo: "O Senhor dos anais", autor:"tal", anoPublicacao:"256523"},
    {titulo:"1984", autor:"Gorge Owrel", anoPublicacao:"1984"},
    {titulo:"Orgulho e Preconceito", autor:"Jane Austen", anoPublicacao:"1880"}
 ];
const titulos = biblioteca.map(biblioteca => biblioteca.titulo);
console.log(titulos);

