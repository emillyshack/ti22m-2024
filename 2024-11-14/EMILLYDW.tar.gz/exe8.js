const aluno = { 
    nome: "Maria",
    idade: 20,
    curso: "Ciência da Computação"

}
    
const {nome, curso} = aluno
console.log(`Nome: ${nome}, Curso: ${curso}`);
